% **************************
% APPLN FUNCTION GENERATION
% **************************

% Load excel file with
[num, text, raw]=xlsread('BPCM_Appln_OS_Tasks_Scheduling_V3.xlsx');

% create new file
fid = fopen('App_task.c','w');

AppName_ColNo = strmatch('Application Function',raw(1,:));
Task_Time_ColNo = strmatch('Task Timing',raw(1,:));
col_no = strmatch('Application Task',raw(1,:));


for i=2:length(text)
    Isappln = strcmp(text{i,col_no},'Y');
    if Isappln
        Task_Time(i,1) = raw{i,Task_Time_ColNo};
    end;
end;

j=1;
for i=1:length(text)
    if i==1
        found_vec(j) = Task_Time(i);
    end;
    
    j=j+1;
    if find(Task_Time(i)==found_vec(:))
        found_vec(j) = Task_Time(i);
    end;
    
end;



