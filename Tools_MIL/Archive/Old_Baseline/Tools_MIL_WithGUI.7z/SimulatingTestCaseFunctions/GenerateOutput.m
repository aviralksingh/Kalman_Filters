function [ output_args ] = GenerateOutput( input_args )
%GENERATEOUTPUT Summary of this function goes here
%   Detailed explanation goes here


end

